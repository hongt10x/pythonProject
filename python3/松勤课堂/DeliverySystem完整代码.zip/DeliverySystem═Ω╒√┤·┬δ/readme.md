框架技术简介
xxxx
代码结构
|-- 项目名称
    |-- readme.md
    |-- .idea
    |   |-- DeliverySystem1028.iml
    |   |-- modules.xml
    |   |-- workspace.xml
    |   |-- inspectionProfiles
    |       |-- profiles_settings.xml
    |       |-- Project_Default.xml
    |-- common
    |   |-- baseApi.py
    |   |-- __init__.py
    |-- configs
    |   |-- __init__.py
    |-- data
    |-- docs
    |-- libs
    |   |-- login.py
    |   |-- shop.py
    |   |-- __init__.py
    |-- outFiles
    |   |-- logs
    |   |-- report
    |   |-- screenshot
    |-- testCase
    |   |-- __init__.py
    |-- utils
    |   |-- __init__.py
    |-- venv
执行流程

