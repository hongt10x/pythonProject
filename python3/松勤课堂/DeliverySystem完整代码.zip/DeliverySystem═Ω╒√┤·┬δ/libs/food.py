#-*- coding: utf-8 -*-
#@File    : food.py
#@Time    : 2022/11/2 21:27
#@Author  : xintian
#@Email   : 1730588479@qq.com
#@Software: PyCharm
#Date:2022/11/2 
from common.baseApi import BaseAPI
class Food(BaseAPI):
    pass